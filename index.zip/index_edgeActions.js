(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol;

   (function(symbolName) {
            
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19727, function(sym, e) {
         sym.play(0);

      });

   })("stage");

})(jQuery, AdobeEdge, "EDGE-15728487");